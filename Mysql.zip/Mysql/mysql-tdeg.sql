-- Instituto T.D.E.G — esquema único MySQL (InnoDB, utf8mb4)
-- Ejecutar en MySQL Workbench: File → Open SQL Script → este archivo → el rayo.

CREATE DATABASE IF NOT EXISTS tdeg
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE tdeg;

CREATE TABLE IF NOT EXISTS alumnos (
  id INT NOT NULL AUTO_INCREMENT,
  dni VARCHAR(20) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  apellido VARCHAR(80) NOT NULL,
  email VARCHAR(120) NULL,
  telefono VARCHAR(40) NULL,
  fecha_nacimiento DATE NULL,
  direccion VARCHAR(200) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  fecha_alta DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_alumnos_dni (dni)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profesores (
  id INT NOT NULL AUTO_INCREMENT,
  dni VARCHAR(20) NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  apellido VARCHAR(80) NOT NULL,
  email VARCHAR(120) NULL,
  telefono VARCHAR(40) NULL,
  especialidad VARCHAR(120) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  fecha_alta DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_profesores_dni (dni)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(80) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(20) NOT NULL DEFAULT 'alumno',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  alumno_id INT NULL,
  profesor_id INT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_username (username),
  CONSTRAINT fk_usuarios_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_usuarios_profesor FOREIGN KEY (profesor_id) REFERENCES profesores (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cursos (
  id INT NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  nombre VARCHAR(120) NOT NULL,
  descripcion TEXT NULL,
  cupo INT NOT NULL DEFAULT 30,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  profesor_id INT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cursos_codigo (codigo),
  CONSTRAINT fk_cursos_profesor FOREIGN KEY (profesor_id) REFERENCES profesores (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS horarios (
  id INT NOT NULL AUTO_INCREMENT,
  curso_id INT NOT NULL,
  dia VARCHAR(20) NOT NULL,
  hora_inicio VARCHAR(5) NOT NULL,
  hora_fin VARCHAR(5) NOT NULL,
  aula VARCHAR(40) NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_horarios_curso FOREIGN KEY (curso_id) REFERENCES cursos (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inscripciones (
  id INT NOT NULL AUTO_INCREMENT,
  alumno_id INT NOT NULL,
  curso_id INT NOT NULL,
  fecha_inscripcion DATETIME NOT NULL,
  estado VARCHAR(20) NOT NULL DEFAULT 'activa',
  comprobante_nro VARCHAR(20) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_alumno_curso (alumno_id, curso_id),
  UNIQUE KEY uq_inscripciones_comprobante (comprobante_nro),
  CONSTRAINT fk_inscripciones_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_inscripciones_curso FOREIGN KEY (curso_id) REFERENCES cursos (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS asistencias (
  id INT NOT NULL AUTO_INCREMENT,
  inscripcion_id INT NOT NULL,
  fecha DATE NOT NULL,
  presente TINYINT(1) NOT NULL DEFAULT 0,
  observaciones VARCHAR(300) NULL,
  usuario_id INT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_asistencia_inscripcion_fecha (inscripcion_id, fecha),
  CONSTRAINT fk_asistencia_inscripcion FOREIGN KEY (inscripcion_id) REFERENCES inscripciones (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_asistencia_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS historial_academico (
  id INT NOT NULL AUTO_INCREMENT,
  alumno_id INT NOT NULL,
  curso_id INT NOT NULL,
  periodo VARCHAR(40) NULL,
  nota FLOAT NULL,
  condicion VARCHAR(30) NULL DEFAULT 'cursando',
  observaciones TEXT NULL,
  fecha DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_historial_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_historial_curso FOREIGN KEY (curso_id) REFERENCES cursos (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS materiales (
  id INT NOT NULL AUTO_INCREMENT,
  curso_id INT NOT NULL,
  profesor_id INT NULL,
  titulo VARCHAR(160) NOT NULL,
  descripcion TEXT NULL,
  archivo VARCHAR(200) NOT NULL,
  nombre_original VARCHAR(200) NOT NULL,
  fecha_carga DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_materiales_curso FOREIGN KEY (curso_id) REFERENCES cursos (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_materiales_profesor FOREIGN KEY (profesor_id) REFERENCES profesores (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS movimientos_caja (
  id INT NOT NULL AUTO_INCREMENT,
  tipo VARCHAR(10) NOT NULL,
  concepto VARCHAR(200) NOT NULL,
  monto DECIMAL(12,2) NOT NULL,
  fecha DATETIME NOT NULL,
  comprobante_nro VARCHAR(20) NULL,
  usuario_id INT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_caja_comprobante (comprobante_nro),
  CONSTRAINT fk_caja_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS eventos (
  id INT NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(160) NOT NULL,
  descripcion TEXT NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NULL,
  tipo VARCHAR(40) NULL DEFAULT 'actividad',
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS auditoria (
  id INT NOT NULL AUTO_INCREMENT,
  usuario VARCHAR(80) NULL,
  accion VARCHAR(40) NOT NULL,
  entidad VARCHAR(40) NOT NULL,
  detalle VARCHAR(300) NULL,
  fecha DATETIME NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

-- Usuario dedicado para la aplicación web (sin usar root)
CREATE USER IF NOT EXISTS 'tdeg_app'@'localhost' IDENTIFIED BY 'TdegApp123!';
CREATE USER IF NOT EXISTS 'tdeg_app'@'127.0.0.1' IDENTIFIED BY 'TdegApp123!';
GRANT ALL PRIVILEGES ON tdeg.* TO 'tdeg_app'@'localhost';
GRANT ALL PRIVILEGES ON tdeg.* TO 'tdeg_app'@'127.0.0.1';
FLUSH PRIVILEGES;
